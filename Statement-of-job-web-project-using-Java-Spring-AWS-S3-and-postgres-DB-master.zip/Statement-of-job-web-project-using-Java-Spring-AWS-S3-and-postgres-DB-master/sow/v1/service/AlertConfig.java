package com.accolite.ppm.sow.v1.service;


public interface AlertConfig {
	public boolean sendAlert(String status);
}
