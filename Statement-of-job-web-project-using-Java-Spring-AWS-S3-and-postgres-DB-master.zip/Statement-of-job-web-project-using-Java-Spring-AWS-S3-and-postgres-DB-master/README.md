# Statement-of-job-web-project-using-Java-Spring-and-AWS-S3
This project is to create a Statement of job web project using Java Spring, AWS S3 and postgres DB.

The project intends to create a statement of work website for a particular company using Java with the spring framework.

The upload and retrival of documents happens from the Amazon S3 storage also for local access we use the postgres DB.



 The entire Backend Flow :
 
![Alt text](https://github.com/akashsrikanth2310/Statement-of-work-web-project-using-Java-Spring-and-AWS-S3/blob/master/Architecture%20Diagrams/Backend%20Flow.png)



The Front End Flow :

![Alt text](https://github.com/akashsrikanth2310/Statement-of-work-web-project-using-Java-Spring-and-AWS-S3/blob/master/Architecture%20Diagrams/frontend_main.png)
